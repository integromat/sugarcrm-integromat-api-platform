<?php
/*
 * A valid platform name requires:
 * - Max length of 127 characters
 * - Valid characters are: a-z, A-Z, 0-9 - (hypen) _ (underscore)
 */
$platforms[] = 'integromat-api';

